BENCHMARKING
------------
The Benchmark ZIP consists of files that help determine if a new build yields the expected output or has introduced bugs.

FILE STRUCTURE
------------

The "1_Baesline_ANS" subfolders contain known solutions that are expected to be correct (ANS files = Answer File Type).

The "2_New_ANS" directory is initially empty. After running the files in the "DAT" directory (via batch processing or otherwise), you can the the resulting ANS files in the "2_New_ANS" directory.

The "DAT" files contain the Input files (DAT) that can be used to create new ANS files from a new build (which can be placed in the "2_New_ANS" directory).
These files may also be used as EXAMPLE files.

FILE NAMING CONVENTION
------------
For the base filename, the first two letters indicate type of run that it is.
EB = Eigen, Banded
ES = Eigen, Static
SB = Sparse, Banded
SS = Sparse, Static

The Eigen solutions (Eigenvalues/Eigenvectors) are for (Givens, Modified Givens, Inverse Power Method, Lanczos) all use ARPACK for the Eigen solution itself.
The first aspect of an Eigen solution is to perform a linear static solution, which may be done via either the Banded solver (LAPACK) or Sparse solver (SuperLU).
Within the DAT file, the linear solver is called via the PARAM card, where BANDED calls LAPACK and SPARSE calls SuperLU.
PARAM, SOLLIB, BANDED
PARAM, SOLLIB, SPARSE

The Static solutions consist of various linear static analysis files.
Within the DAT file, the linear solver is called via the PARAM card, where BANDED calls LAPACK and SPARSE calls SuperLU.
PARAM, SOLLIB, BANDED
PARAM, SOLLIB, SPARSE


OVERALL PROCEDURE
-----------------

Step 1 (Recommended, but may not be necessary): Where applicable, remove all files from the "DAT" directory other than DAT files.
Similarly, where applicable, remove all files from the "2_New_ANS" directory.
These processes may be done via the "Clean_Both" batch file.

Step 2: Via a "new" MYSTRAN executable (newly compiled), run all of the files in the "DAT" directory.
This may be performed via a batch file (see Batch_DAT.bat for reference).
Note that after running the DAT files, there will be output files other than the just the ANS (which include BUG, ERR, F06, NEU, etc.). These files are created for reference.

Step 3: Copy the ANS files from the "DAT" directory to the "2_New_ANS" directory.

Step 4: Use the Excel Benchmark tool to compare the "1_Baseline_ANS" directory to the "2_New_ANS" directory.
The number of files and file name (minus the extension) must match exactly.
The most important notable cell inputs are K5, K6, K7. These need to be changed if you used a different directory structure than "C:\Baseline\.."

