ITEM 1:
The following test cases have not produced consistent values for some of the ELFORCE, GPFORCE, MPFACTOR, SPCFORCE, STRESS values.
It is currently unknown why this is the case.
In other words, they can not be easily benchmarked when these are turned on.
However, the Eigenvalues and Eigenvectors can still be part of the benchmark process.
In the meantime, these files have been modified as shown below:

EB-ALL-ELEM-TEST-GIV
ES-ALL-ELEM-TEST-GIV
EB-ALL-ELEM-TEST-LANCZOS-MODE-2-DPB
ES-ALL-ELEM-TEST-LANCZOS-MODE-2-DPB

---MODIFICATIONS----
DISP          = ALL
ECHO          = UNSORT
$COMMENTED OUT DUE TO BENCHMARK ISSUE: ELFORCE(BOTH) = ALL
$COMMENTED OUT DUE TO BENCHMARK ISSUE: GPFORCE       = ALL
MEFFMASS      = ALL
MPCFORCE      = ALL
$COMMENTED OUT DUE TO BENCHMARK ISSUE: MPFACTOR      = ALL
OLOAD         = ALL
$COMMENTED OUT DUE TO BENCHMARK ISSUE: SPCFORCE      = ALL
$COMMENTED OUT DUE TO BENCHMARK ISSUE: STRESS        = ALL


ITEM 2:
For the Lanczos Eigen solver (EIGRL), there is no parameter to normalize to a node (unlike for EIGR).
This means that the Eigenvectors can be different (but still correct).
For example, it is common to have the signs of the Eigenvector flipped for two different runs.
However, this means they can not be used for validation.
As a temporary possible solution, only 2 Eigens are requested (instead of 4).

EB-ALL-ELEM-TEST-LANCZOS-MODE-2-DPB
ES-ALL-ELEM-TEST-LANCZOS-MODE-2-DPB

ITEM 3:
Bug may have introduced in Intrdoced in 13.1
For the following files:
SB-RBE2-01-CBAR-01
SS-RBE2-01-CBAR-01

These entries caused an error, but did not cause an error in prior builds.
ELDATA(1,PUNCH) = ALL
ELDATA(2,PUNCH) = ALL
ELDATA(3,PUNCH) = ALL
ELDATA(4,PUNCH) = ALL
ELDATA(5,PUNCH) = ALL

ITEM4:
Check the manual SOLLIB Param to see if it says that BANDED is always used for an Eigen solution.
Are CBUSH values in ANS files?
Address SOLVE_EQNS_1_BANDIT