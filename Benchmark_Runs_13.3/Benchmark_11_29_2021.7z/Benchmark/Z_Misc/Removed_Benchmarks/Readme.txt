These files are in a TBD state.

The SB-SOLVE_EQNS_1_BANDIT.DAT and SS-SOLVE_EQNS_1_BANDIT.DAT were depreciated due to potential issues the BANDIT subroutine.
This issue has not been fully addressed or verified.

The EB-CB-EXAMPLE-12.DAT and ES-CB-EXAMPLE-12.DAT were because of large differences between the baseline runs and other runs.
This issue has not been addressed.