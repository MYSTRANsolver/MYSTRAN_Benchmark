The path for MYSTRAN.exe and the Test Runs are defined in the batch file.
The defaults are for MYSTRAN.exe to be in C:\MYSTRAN\TestRuns\MYSTRAN.exe and the subdirectories for the Test Runs to be in C:\MYSTRAN\TestRuns
You can use Find/Replace to change these paths in the batch file.

NOTE: To exit the batch file, use CNTRL+C twice.