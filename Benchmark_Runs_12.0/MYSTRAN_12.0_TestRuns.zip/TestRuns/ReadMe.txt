BENCHMARKING
------------
The Test Runs ZIP consists of files that help determine if a new build yields the expected output or has introduced bugs.

The "Archive" folders contain known solutions that are expected to be correct.
These files were originally "ANS" files, which is a native output from MYSTRAN and often used for testing purposes.
The ANS files have been renamed to "ARC" files to indicate they are Archive veersion of the ANS file.
An ANS file "Answer file" is a native MYSTRAN output. The objective it run the DAT files (via the batch file if you so choose) and compare the ANS files (from a new build) to the ARC files.

The "Current" files contiain the Input files (DAT) that can be used to create the current (new) ANS files from a new build.
If a user wants to determine if a new MYSTRAN.EXE produces the correct results, they would run the DAT files and compare the resulting new ANS files to the "Archive" (ARC) files.
Note that after running the DAT files, there will be outfiles other than the just the ANS (which include BUG, ERR, F06, NEU). These files are created for reference.

The "Eigen" folder are Eigen solutions (Eigenvalues/Eigenvectors), where various Eigen solutions (Givens, Modified Givens, Inverse Power Method, Lancos) are used (all DAT files ARPACK for the Eigen solution).
The first aspect of an Eigen solution is to perform a linear static solution, which may be done via either the Banded solver (LAPACK) or Sparse solver (SuperLU).
Within the DAT file, the linear solvers are called via either the following PARAM card, where BANDED calls LAPACK and SPARSE calls SuperLU.
PARAM, SOLLIB, BANDED
PARAM, SOLLIB, SPARSE

The "Static" folder consists of various linear static analysis files.
The files may use either the Banded solver (via LAPACK) or the Sparse solver (via SuperLU).

TEST RUNS BATCH FILE
--------------------
In Windows, a batch file can be used to run all the DAT files in the TestRuns subfolders.
See the readme file Test_Runs_Readme.txt for instructions on how to use the Test_Runs.bat batch file.